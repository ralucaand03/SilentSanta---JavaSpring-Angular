package com.group.silent_santa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootIntellijIoApplicationTests {

	@Test
	void contextLoads() {
	}

}
